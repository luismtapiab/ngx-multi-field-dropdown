import * as _angular_core from '@angular/core';
import { OnInit, ElementRef, EventEmitter, OnDestroy } from '@angular/core';
import { Subject } from 'rxjs';

declare class MultiFieldDropdownComponent implements OnInit {
    private eRef;
    isOpen: _angular_core.WritableSignal<boolean>;
    constructor(eRef: ElementRef);
    /** Items to display in the dropdown */
    items: _angular_core.InputSignal<any[]>;
    /** Keys of the object to use for searching and display */
    displayKeys: _angular_core.InputSignal<string[]>;
    /** Text to display when no results are found */
    notFoundText: _angular_core.InputSignal<string>;
    /** Placeholder for the search input */
    placeholder: _angular_core.InputSignal<string>;
    /** Debounce time in milliseconds for the search input */
    debounceTime: _angular_core.InputSignal<number>;
    selectionChange: EventEmitter<any>;
    selectedItemIndex: _angular_core.WritableSignal<number>;
    displayed: _angular_core.WritableSignal<string>;
    searchTerm: _angular_core.WritableSignal<string>;
    filteredItems: _angular_core.Signal<any[]>;
    dropdownBox: _angular_core.Signal<ElementRef<any>>;
    searchInput: _angular_core.Signal<ElementRef<any>>;
    ngOnInit(): void;
    toggleDropdown(): void;
    selectItem(item: any, index: number): void;
    onSearchChange(value: string): void;
    clickout(event: Event): void;
    onFocus(): void;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<MultiFieldDropdownComponent, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<MultiFieldDropdownComponent, "ngx-multi-field-dropdown", never, { "items": { "alias": "items"; "required": false; "isSignal": true; }; "displayKeys": { "alias": "displayKeys"; "required": false; "isSignal": true; }; "notFoundText": { "alias": "notFoundText"; "required": false; "isSignal": true; }; "placeholder": { "alias": "placeholder"; "required": false; "isSignal": true; }; "debounceTime": { "alias": "debounceTime"; "required": false; "isSignal": true; }; }, { "selectionChange": "selectionChange"; }, never, never, true, never>;
}

declare abstract class AbstractDebounceDirective implements OnInit, OnDestroy {
    debounceTime: number;
    onEvent: EventEmitter<any>;
    protected emitEvent$: Subject<any>;
    protected subscription$: Subject<void>;
    ngOnInit(): void;
    emitChange(value: any): void;
    ngOnDestroy(): void;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<AbstractDebounceDirective, never>;
    static ɵdir: _angular_core.ɵɵDirectiveDeclaration<AbstractDebounceDirective, never, never, { "debounceTime": { "alias": "debounceTime"; "required": false; }; }, { "onEvent": "onEvent"; }, never, never, true, never>;
}

declare class DebouncedInputDirective extends AbstractDebounceDirective {
    constructor();
    onInput(target: EventTarget | null): void;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<DebouncedInputDirective, never>;
    static ɵdir: _angular_core.ɵɵDirectiveDeclaration<DebouncedInputDirective, "input[debouncedInput]", never, {}, {}, never, never, true, never>;
}

export { AbstractDebounceDirective, DebouncedInputDirective, MultiFieldDropdownComponent };
