import * as i0 from '@angular/core';
import { EventEmitter, Output, Input, Directive, HostListener, signal, input, computed, viewChild, ChangeDetectionStrategy, Component } from '@angular/core';
import * as i1 from '@angular/forms';
import { FormsModule } from '@angular/forms';
import { Subject } from 'rxjs';
import { takeUntil, debounceTime, distinctUntilChanged, tap } from 'rxjs/operators';

class AbstractDebounceDirective {
    debounceTime = 500;
    onEvent = new EventEmitter();
    emitEvent$ = new Subject();
    subscription$ = new Subject();
    ngOnInit() {
        this.emitEvent$
            .pipe(takeUntil(this.subscription$), debounceTime(this.debounceTime), distinctUntilChanged(), tap((value) => this.emitChange(value)))
            .subscribe();
    }
    emitChange(value) {
        this.onEvent.emit(value);
    }
    ngOnDestroy() {
        this.subscription$.next();
        this.subscription$.complete();
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.13", ngImport: i0, type: AbstractDebounceDirective, deps: [], target: i0.ɵɵFactoryTarget.Directive });
    static ɵdir = i0.ɵɵngDeclareDirective({ minVersion: "14.0.0", version: "21.2.13", type: AbstractDebounceDirective, isStandalone: true, inputs: { debounceTime: "debounceTime" }, outputs: { onEvent: "onEvent" }, ngImport: i0 });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.13", ngImport: i0, type: AbstractDebounceDirective, decorators: [{
            type: Directive,
            args: [{
                    standalone: true
                }]
        }], propDecorators: { debounceTime: [{
                type: Input
            }], onEvent: [{
                type: Output
            }] } });

class DebouncedInputDirective extends AbstractDebounceDirective {
    constructor() {
        super();
    }
    onInput(target) {
        this.emitEvent$.next(target.value);
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.13", ngImport: i0, type: DebouncedInputDirective, deps: [], target: i0.ɵɵFactoryTarget.Directive });
    static ɵdir = i0.ɵɵngDeclareDirective({ minVersion: "14.0.0", version: "21.2.13", type: DebouncedInputDirective, isStandalone: true, selector: "input[debouncedInput]", host: { listeners: { "input": "onInput($event.target)" } }, usesInheritance: true, ngImport: i0 });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.13", ngImport: i0, type: DebouncedInputDirective, decorators: [{
            type: Directive,
            args: [{
                    standalone: true,
                    selector: 'input[debouncedInput]',
                }]
        }], ctorParameters: () => [], propDecorators: { onInput: [{
                type: HostListener,
                args: ["input", ["$event.target"]]
            }] } });

class MultiFieldDropdownComponent {
    eRef;
    isOpen = signal(false, ...(ngDevMode ? [{ debugName: "isOpen" }] : /* istanbul ignore next */ []));
    constructor(eRef) {
        this.eRef = eRef;
    }
    /** Items to display in the dropdown */
    items = input([], ...(ngDevMode ? [{ debugName: "items" }] : /* istanbul ignore next */ []));
    /** Keys of the object to use for searching and display */
    displayKeys = input(['name'], ...(ngDevMode ? [{ debugName: "displayKeys" }] : /* istanbul ignore next */ []));
    /** Text to display when no results are found */
    notFoundText = input('No results found', ...(ngDevMode ? [{ debugName: "notFoundText" }] : /* istanbul ignore next */ []));
    /** Placeholder for the search input */
    placeholder = input('Search...', ...(ngDevMode ? [{ debugName: "placeholder" }] : /* istanbul ignore next */ []));
    /** Debounce time in milliseconds for the search input */
    debounceTime = input(300, ...(ngDevMode ? [{ debugName: "debounceTime" }] : /* istanbul ignore next */ []));
    selectionChange = new EventEmitter();
    selectedItemIndex = signal(-1, ...(ngDevMode ? [{ debugName: "selectedItemIndex" }] : /* istanbul ignore next */ []));
    displayed = signal('', ...(ngDevMode ? [{ debugName: "displayed" }] : /* istanbul ignore next */ []));
    searchTerm = signal('', ...(ngDevMode ? [{ debugName: "searchTerm" }] : /* istanbul ignore next */ []));
    filteredItems = computed(() => {
        const term = this.searchTerm().toLowerCase().trim();
        const searchWords = term.split(/\s+/).filter((word) => word.length > 0);
        const currentItems = this.items();
        if (searchWords.length === 0) {
            return currentItems;
        }
        return currentItems.filter((item) => {
            return searchWords.every((word) => {
                return this.displayKeys().some((key) => {
                    const itemValue = String(item[key] ?? '').toLowerCase();
                    return itemValue.includes(word);
                });
            });
        });
    }, ...(ngDevMode ? [{ debugName: "filteredItems" }] : /* istanbul ignore next */ []));
    dropdownBox = viewChild('dropdownBox', ...(ngDevMode ? [{ debugName: "dropdownBox" }] : /* istanbul ignore next */ []));
    searchInput = viewChild('searchInput', ...(ngDevMode ? [{ debugName: "searchInput" }] : /* istanbul ignore next */ []));
    ngOnInit() { }
    toggleDropdown() {
        this.isOpen.update((v) => !v);
        if (this.isOpen()) {
            setTimeout(() => {
                this.searchInput()?.nativeElement.focus();
            }, 0);
        }
    }
    selectItem(item, index) {
        this.selectedItemIndex.set(index);
        if (item) {
            const displayValue = this.displayKeys()
                .map((key) => item[key])
                .filter((val) => !!val)
                .join(' ');
            this.displayed.set(displayValue);
        }
        else {
            this.displayed.set('');
        }
        this.selectionChange.emit(item);
        this.searchTerm.set('');
        this.isOpen.set(false);
    }
    onSearchChange(value) {
        this.searchTerm.set(value);
    }
    clickout(event) {
        if (!this.eRef.nativeElement.contains(event.target)) {
            this.isOpen.set(false);
        }
    }
    onFocus() {
        this.isOpen.set(true);
    }
    static ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "21.2.13", ngImport: i0, type: MultiFieldDropdownComponent, deps: [{ token: i0.ElementRef }], target: i0.ɵɵFactoryTarget.Component });
    static ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.0.0", version: "21.2.13", type: MultiFieldDropdownComponent, isStandalone: true, selector: "ngx-multi-field-dropdown", inputs: { items: { classPropertyName: "items", publicName: "items", isSignal: true, isRequired: false, transformFunction: null }, displayKeys: { classPropertyName: "displayKeys", publicName: "displayKeys", isSignal: true, isRequired: false, transformFunction: null }, notFoundText: { classPropertyName: "notFoundText", publicName: "notFoundText", isSignal: true, isRequired: false, transformFunction: null }, placeholder: { classPropertyName: "placeholder", publicName: "placeholder", isSignal: true, isRequired: false, transformFunction: null }, debounceTime: { classPropertyName: "debounceTime", publicName: "debounceTime", isSignal: true, isRequired: false, transformFunction: null } }, outputs: { selectionChange: "selectionChange" }, host: { listeners: { "document:click": "clickout($event)" } }, viewQueries: [{ propertyName: "dropdownBox", first: true, predicate: ["dropdownBox"], descendants: true, isSignal: true }, { propertyName: "searchInput", first: true, predicate: ["searchInput"], descendants: true, isSignal: true }], ngImport: i0, template: "<div #dropdownBox class=\"ngx-mfd\" [class.ngx-mfd--open]=\"isOpen()\">\n  <div class=\"ngx-mfd-trigger\" (click)=\"toggleDropdown()\">\n    <span class=\"ngx-mfd-trigger-text\" [class.ngx-mfd-trigger-text--placeholder]=\"!displayed()\">\n      {{ displayed() || placeholder() }}\n    </span>\n    <div class=\"ngx-mfd-trigger-icon\">\n      <svg xmlns=\"http://www.w3.org/2000/svg\" width=\"16\" height=\"16\" viewBox=\"0 0 24 24\" fill=\"none\" stroke=\"currentColor\" stroke-width=\"2\" stroke-linecap=\"round\" stroke-linejoin=\"round\">\n        <path d=\"m6 9 6 6 6-6\"/>\n      </svg>\n    </div>\n  </div>\n\n  <div class=\"ngx-mfd-panel\">\n    <div class=\"ngx-mfd-search\">\n      <div class=\"ngx-mfd-search-icon\">\n        <svg xmlns=\"http://www.w3.org/2000/svg\" width=\"14\" height=\"14\" viewBox=\"0 0 24 24\" fill=\"none\" stroke=\"currentColor\" stroke-width=\"2\" stroke-linecap=\"round\" stroke-linejoin=\"round\">\n          <circle cx=\"11\" cy=\"11\" r=\"8\"/><path d=\"m21 21-4.3-4.3\"/>\n        </svg>\n      </div>\n      <input \n        #searchInput \n        type=\"text\" \n        [ngModel]=\"searchTerm()\"\n        (ngModelChange)=\"onSearchChange($event)\" \n        debouncedInput \n        [debounceTime]=\"debounceTime()\" \n        (focus)=\"onFocus()\"\n        [placeholder]=\"placeholder()\"\n        class=\"ngx-mfd-search-input\"\n      >\n    </div>\n\n    <ul class=\"ngx-mfd-list\">\n      @if(selectedItemIndex() !== -1) {\n        <li class=\"ngx-mfd-option ngx-mfd-option--reset\" \n            (click)=\"selectItem(null, -1)\">\n          Clear selection\n        </li>\n      }\n      \n      @for(item of filteredItems(); track item; let i = $index) {\n        <li class=\"ngx-mfd-option\" \n            [class.ngx-mfd-option--selected]=\"selectedItemIndex() === i\"\n            (click)=\"selectItem(item, i)\">\n          <div class=\"ngx-mfd-option-content\">\n            @for(key of displayKeys(); track key; let last = $last) {\n              <span class=\"ngx-mfd-field-value\">{{ item[key] }}</span>\n              @if(!last) {\n                <span class=\"ngx-mfd-field-separator\"> </span>\n              }\n            }\n          </div>\n          @if(selectedItemIndex() === i) {\n            <div class=\"ngx-mfd-check\">\n              <svg xmlns=\"http://www.w3.org/2000/svg\" width=\"14\" height=\"14\" viewBox=\"0 0 24 24\" fill=\"none\" stroke=\"currentColor\" stroke-width=\"2\" stroke-linecap=\"round\" stroke-linejoin=\"round\">\n                <path d=\"M20 6 9 17l-5-5\"/>\n              </svg>\n            </div>\n          }\n        </li>\n      } @empty {\n        <li class=\"ngx-mfd-empty\">\n          {{ notFoundText() }}\n        </li>\n      }\n    </ul>\n  </div>\n</div>\n", styles: [":host{display:block;font-family:inherit;--mfd-primary: #3b82f6;--mfd-bg: #ffffff;--mfd-border: #e2e8f0;--mfd-text: #1e293b;--mfd-text-muted: #64748b;--mfd-hover: #f8fafc;--mfd-selected-bg: #eff6ff;--mfd-radius: .5rem;--mfd-shadow: 0 10px 15px -3px rgb(0 0 0 / .1), 0 4px 6px -4px rgb(0 0 0 / .1)}.ngx-mfd{position:relative;width:100%;-webkit-user-select:none;user-select:none;color:var(--mfd-text);box-sizing:border-box}.ngx-mfd *{box-sizing:border-box}.ngx-mfd-trigger{display:flex;align-items:center;justify-content:space-between;padding:.625rem 1rem;background:var(--mfd-bg);border:1px solid var(--mfd-border);border-radius:var(--mfd-radius);cursor:pointer;min-height:2.75rem;transition:all .2s cubic-bezier(.4,0,.2,1)}.ngx-mfd-trigger:hover{border-color:#cbd5e1}.ngx-mfd-trigger-text{font-size:.875rem;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}.ngx-mfd-trigger-text--placeholder{color:var(--mfd-text-muted)}.ngx-mfd-trigger-icon{color:var(--mfd-text-muted);transition:transform .2s ease;margin-left:.5rem;display:flex}.ngx-mfd--open .ngx-mfd-trigger{border-color:var(--mfd-primary);box-shadow:0 0 0 3px #3b82f61a}.ngx-mfd--open .ngx-mfd-trigger-icon{transform:rotate(180deg)}.ngx-mfd--open .ngx-mfd-panel{opacity:1;transform:translateY(0);visibility:visible}.ngx-mfd-panel{position:absolute;top:calc(100% + .5rem);left:0;width:100%;background:var(--mfd-bg);border:1px solid var(--mfd-border);border-radius:var(--mfd-radius);box-shadow:var(--mfd-shadow);z-index:1000;opacity:0;visibility:hidden;transform:translateY(-8px);transition:all .2s cubic-bezier(.4,0,.2,1);overflow:hidden}.ngx-mfd-search{display:flex;align-items:center;padding:.75rem;border-bottom:1px solid var(--mfd-border);gap:.5rem}.ngx-mfd-search-icon{color:var(--mfd-text-muted);display:flex}.ngx-mfd-search-input{width:100%;border:none;outline:none;font-size:.875rem;background:transparent;color:var(--mfd-text);font-family:inherit}.ngx-mfd-search-input::placeholder{color:var(--mfd-text-muted)}.ngx-mfd-list{list-style:none;margin:0;padding:.375rem;max-height:250px;overflow-y:auto}.ngx-mfd-list::-webkit-scrollbar{width:6px}.ngx-mfd-list::-webkit-scrollbar-thumb{background:var(--mfd-border);border-radius:10px}.ngx-mfd-option{display:flex;align-items:center;justify-content:space-between;padding:.625rem .75rem;border-radius:.375rem;cursor:pointer;font-size:.875rem;transition:background .15s ease}.ngx-mfd-option:hover{background:var(--mfd-hover)}.ngx-mfd-option--selected{background:var(--mfd-selected-bg);color:var(--mfd-primary);font-weight:500}.ngx-mfd-option--reset{color:var(--mfd-text-muted);font-size:.75rem;padding:.375rem .75rem;border-bottom:1px solid var(--mfd-border);border-radius:0;margin-bottom:.25rem;justify-content:flex-end;background:transparent}.ngx-mfd-option--reset:hover{color:#ef4444;background:transparent;text-decoration:underline}.ngx-mfd-option-content{display:flex;flex-wrap:wrap;gap:.25rem}.ngx-mfd-check{color:var(--mfd-primary);display:flex}.ngx-mfd-empty{padding:2rem 1rem;text-align:center;color:var(--mfd-text-muted);font-size:.875rem}\n"], dependencies: [{ kind: "ngmodule", type: FormsModule }, { kind: "directive", type: i1.DefaultValueAccessor, selector: "input:not([type=checkbox])[formControlName],textarea[formControlName],input:not([type=checkbox])[formControl],textarea[formControl],input:not([type=checkbox])[ngModel],textarea[ngModel],[ngDefaultControl]" }, { kind: "directive", type: i1.NgControlStatus, selector: "[formControlName],[ngModel],[formControl]" }, { kind: "directive", type: i1.NgModel, selector: "[ngModel]:not([formControlName]):not([formControl])", inputs: ["name", "disabled", "ngModel", "ngModelOptions"], outputs: ["ngModelChange"], exportAs: ["ngModel"] }, { kind: "directive", type: DebouncedInputDirective, selector: "input[debouncedInput]" }], changeDetection: i0.ChangeDetectionStrategy.OnPush });
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "21.2.13", ngImport: i0, type: MultiFieldDropdownComponent, decorators: [{
            type: Component,
            args: [{ selector: 'ngx-multi-field-dropdown', standalone: true, imports: [FormsModule, DebouncedInputDirective], changeDetection: ChangeDetectionStrategy.OnPush, template: "<div #dropdownBox class=\"ngx-mfd\" [class.ngx-mfd--open]=\"isOpen()\">\n  <div class=\"ngx-mfd-trigger\" (click)=\"toggleDropdown()\">\n    <span class=\"ngx-mfd-trigger-text\" [class.ngx-mfd-trigger-text--placeholder]=\"!displayed()\">\n      {{ displayed() || placeholder() }}\n    </span>\n    <div class=\"ngx-mfd-trigger-icon\">\n      <svg xmlns=\"http://www.w3.org/2000/svg\" width=\"16\" height=\"16\" viewBox=\"0 0 24 24\" fill=\"none\" stroke=\"currentColor\" stroke-width=\"2\" stroke-linecap=\"round\" stroke-linejoin=\"round\">\n        <path d=\"m6 9 6 6 6-6\"/>\n      </svg>\n    </div>\n  </div>\n\n  <div class=\"ngx-mfd-panel\">\n    <div class=\"ngx-mfd-search\">\n      <div class=\"ngx-mfd-search-icon\">\n        <svg xmlns=\"http://www.w3.org/2000/svg\" width=\"14\" height=\"14\" viewBox=\"0 0 24 24\" fill=\"none\" stroke=\"currentColor\" stroke-width=\"2\" stroke-linecap=\"round\" stroke-linejoin=\"round\">\n          <circle cx=\"11\" cy=\"11\" r=\"8\"/><path d=\"m21 21-4.3-4.3\"/>\n        </svg>\n      </div>\n      <input \n        #searchInput \n        type=\"text\" \n        [ngModel]=\"searchTerm()\"\n        (ngModelChange)=\"onSearchChange($event)\" \n        debouncedInput \n        [debounceTime]=\"debounceTime()\" \n        (focus)=\"onFocus()\"\n        [placeholder]=\"placeholder()\"\n        class=\"ngx-mfd-search-input\"\n      >\n    </div>\n\n    <ul class=\"ngx-mfd-list\">\n      @if(selectedItemIndex() !== -1) {\n        <li class=\"ngx-mfd-option ngx-mfd-option--reset\" \n            (click)=\"selectItem(null, -1)\">\n          Clear selection\n        </li>\n      }\n      \n      @for(item of filteredItems(); track item; let i = $index) {\n        <li class=\"ngx-mfd-option\" \n            [class.ngx-mfd-option--selected]=\"selectedItemIndex() === i\"\n            (click)=\"selectItem(item, i)\">\n          <div class=\"ngx-mfd-option-content\">\n            @for(key of displayKeys(); track key; let last = $last) {\n              <span class=\"ngx-mfd-field-value\">{{ item[key] }}</span>\n              @if(!last) {\n                <span class=\"ngx-mfd-field-separator\"> </span>\n              }\n            }\n          </div>\n          @if(selectedItemIndex() === i) {\n            <div class=\"ngx-mfd-check\">\n              <svg xmlns=\"http://www.w3.org/2000/svg\" width=\"14\" height=\"14\" viewBox=\"0 0 24 24\" fill=\"none\" stroke=\"currentColor\" stroke-width=\"2\" stroke-linecap=\"round\" stroke-linejoin=\"round\">\n                <path d=\"M20 6 9 17l-5-5\"/>\n              </svg>\n            </div>\n          }\n        </li>\n      } @empty {\n        <li class=\"ngx-mfd-empty\">\n          {{ notFoundText() }}\n        </li>\n      }\n    </ul>\n  </div>\n</div>\n", styles: [":host{display:block;font-family:inherit;--mfd-primary: #3b82f6;--mfd-bg: #ffffff;--mfd-border: #e2e8f0;--mfd-text: #1e293b;--mfd-text-muted: #64748b;--mfd-hover: #f8fafc;--mfd-selected-bg: #eff6ff;--mfd-radius: .5rem;--mfd-shadow: 0 10px 15px -3px rgb(0 0 0 / .1), 0 4px 6px -4px rgb(0 0 0 / .1)}.ngx-mfd{position:relative;width:100%;-webkit-user-select:none;user-select:none;color:var(--mfd-text);box-sizing:border-box}.ngx-mfd *{box-sizing:border-box}.ngx-mfd-trigger{display:flex;align-items:center;justify-content:space-between;padding:.625rem 1rem;background:var(--mfd-bg);border:1px solid var(--mfd-border);border-radius:var(--mfd-radius);cursor:pointer;min-height:2.75rem;transition:all .2s cubic-bezier(.4,0,.2,1)}.ngx-mfd-trigger:hover{border-color:#cbd5e1}.ngx-mfd-trigger-text{font-size:.875rem;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}.ngx-mfd-trigger-text--placeholder{color:var(--mfd-text-muted)}.ngx-mfd-trigger-icon{color:var(--mfd-text-muted);transition:transform .2s ease;margin-left:.5rem;display:flex}.ngx-mfd--open .ngx-mfd-trigger{border-color:var(--mfd-primary);box-shadow:0 0 0 3px #3b82f61a}.ngx-mfd--open .ngx-mfd-trigger-icon{transform:rotate(180deg)}.ngx-mfd--open .ngx-mfd-panel{opacity:1;transform:translateY(0);visibility:visible}.ngx-mfd-panel{position:absolute;top:calc(100% + .5rem);left:0;width:100%;background:var(--mfd-bg);border:1px solid var(--mfd-border);border-radius:var(--mfd-radius);box-shadow:var(--mfd-shadow);z-index:1000;opacity:0;visibility:hidden;transform:translateY(-8px);transition:all .2s cubic-bezier(.4,0,.2,1);overflow:hidden}.ngx-mfd-search{display:flex;align-items:center;padding:.75rem;border-bottom:1px solid var(--mfd-border);gap:.5rem}.ngx-mfd-search-icon{color:var(--mfd-text-muted);display:flex}.ngx-mfd-search-input{width:100%;border:none;outline:none;font-size:.875rem;background:transparent;color:var(--mfd-text);font-family:inherit}.ngx-mfd-search-input::placeholder{color:var(--mfd-text-muted)}.ngx-mfd-list{list-style:none;margin:0;padding:.375rem;max-height:250px;overflow-y:auto}.ngx-mfd-list::-webkit-scrollbar{width:6px}.ngx-mfd-list::-webkit-scrollbar-thumb{background:var(--mfd-border);border-radius:10px}.ngx-mfd-option{display:flex;align-items:center;justify-content:space-between;padding:.625rem .75rem;border-radius:.375rem;cursor:pointer;font-size:.875rem;transition:background .15s ease}.ngx-mfd-option:hover{background:var(--mfd-hover)}.ngx-mfd-option--selected{background:var(--mfd-selected-bg);color:var(--mfd-primary);font-weight:500}.ngx-mfd-option--reset{color:var(--mfd-text-muted);font-size:.75rem;padding:.375rem .75rem;border-bottom:1px solid var(--mfd-border);border-radius:0;margin-bottom:.25rem;justify-content:flex-end;background:transparent}.ngx-mfd-option--reset:hover{color:#ef4444;background:transparent;text-decoration:underline}.ngx-mfd-option-content{display:flex;flex-wrap:wrap;gap:.25rem}.ngx-mfd-check{color:var(--mfd-primary);display:flex}.ngx-mfd-empty{padding:2rem 1rem;text-align:center;color:var(--mfd-text-muted);font-size:.875rem}\n"] }]
        }], ctorParameters: () => [{ type: i0.ElementRef }], propDecorators: { items: [{ type: i0.Input, args: [{ isSignal: true, alias: "items", required: false }] }], displayKeys: [{ type: i0.Input, args: [{ isSignal: true, alias: "displayKeys", required: false }] }], notFoundText: [{ type: i0.Input, args: [{ isSignal: true, alias: "notFoundText", required: false }] }], placeholder: [{ type: i0.Input, args: [{ isSignal: true, alias: "placeholder", required: false }] }], debounceTime: [{ type: i0.Input, args: [{ isSignal: true, alias: "debounceTime", required: false }] }], selectionChange: [{
                type: Output
            }], dropdownBox: [{ type: i0.ViewChild, args: ['dropdownBox', { isSignal: true }] }], searchInput: [{ type: i0.ViewChild, args: ['searchInput', { isSignal: true }] }], clickout: [{
                type: HostListener,
                args: ['document:click', ['$event']]
            }] } });

/**
 * Generated bundle index. Do not edit.
 */

export { AbstractDebounceDirective, DebouncedInputDirective, MultiFieldDropdownComponent };
//# sourceMappingURL=ngx-multi-field-dropdown.mjs.map
